# Pixel 6 Sensi Lab — Android APK project

This Android wrapper displays the sensitivity generator locally inside a native Android app. The generator works offline after installation.

## Build the APK on GitHub
1. Create a GitHub repository (or use an existing repository).
2. Upload the **contents** of this folder to the repository root. Make sure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab.
4. Select **Build Pixel 6 Sensi Lab APK** and wait for the run to finish.
5. Open the completed workflow run and download the `Pixel6-Sensi-Lab-APK` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open it on your Pixel 6 to install.

The Android installation confirmation must be approved on the phone. This project does not install itself or change phone security settings.
